<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title><?php echo TITULO;?></title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/styleMenu.css">
	<link rel="stylesheet" href="css/styleCad.css">
	<link rel="stylesheet" href="css/styleTable.css">
	<link rel="stylesheet" href="css/styleList.css">
	<link rel="stylesheet" href="fonts/fontes.css">
	<link rel="stylesheet" href="css/styleCat.css">
	<link rel="stylesheet" href="css/styleBtnPesq.css">
	<link rel="stylesheet" href="icons/boxicons-2.0.9/css/animations.css">
	<link rel="stylesheet" href="icons/boxicons-2.0.9/css/boxicons.css">
	<link rel="stylesheet" href="icons/boxicons-2.0.9/css/boxicons.min.css">
	<link rel="stylesheet" href="icons/boxicons-2.0.9/css/transformations.css">
</head>
<body>