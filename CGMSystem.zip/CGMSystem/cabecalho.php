<!DOCTYPE html>
<html lang="PT-br">
<head>
<title><?php echo TITULO;?></title>
<meta charset="utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link rel="stylesheet" href="css/img.css"/>
<link rel="stylesheet" href="css/cor.css"/>
</head>
<body>