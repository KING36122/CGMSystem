<?php
    define("TITULO", "INICIAL");
    // include "menu.php";
    // include "cabecalho.php";
    include "menuInicial.php";
?>
<main>
    


</main>


<?php
    include "rodape.php";
?>